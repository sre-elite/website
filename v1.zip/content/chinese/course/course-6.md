---
title: "课程开发中"
date: 2019-07-06T15:27:17+06:00
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# meta description
description : "课程开发中。"
# course thumbnail
image: "images/courses/course-6.jpg"
# taxonomy
category: "SRE"
# teacher
teacher: ""
# duration
duration : "1 天"
# weekly
weekly : "5 小时"
# course fee
fee : "$699/人"
# apply url
apply_url : "#"
# type
type: "course"
---

## 课程简介

课程开发中。如有培训需求，点这里[联系我们](/contact/)。
