---
title: "研究方向"
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# meta description
description : "每年设定不同的方向做集体深度研究，也会对一些热点技术进行深入探讨。"
---