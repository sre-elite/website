---
title: "辅导"
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# image
image: "images/about/about-page.jpg"
# meta description
description : "深度参与“SRE精英联盟”组织内部的活动，参与分享和贡献，参加内部例会。"
---

## 辅导&交流

**_精英联盟组织希望能陪伴式的加速度带新成员企业快速成长。_**

联盟是一个持续学习的集体，我们希望能够帮助新成员企业快速成长，我们的专家团队会定期与新成员企业进行交流，帮助他们解决在SRE实践中遇到的问题，帮助他们快速成长。
