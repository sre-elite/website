---
title: "参与内部例会"
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# scholarship image
image: "images/scholarship/scholarship-item-1.jpg"
# meta description
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. dolore magna aliqua. Ut enim ad minim veniam, quis nostrud."
---

* 双周线上形式
* 不定期在各个城市线下小范围研讨会
* 联盟专家间点对点切磋
* 微信群交流
