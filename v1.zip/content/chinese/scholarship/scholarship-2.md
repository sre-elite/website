---
title: "行业现状调研"
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# scholarship image
image: "images/scholarship/scholarship-item-2.jpg"
# meta description
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. dolore magna aliqua. Ut enim ad minim veniam, quis nostrud."
---

* 紧跟行业发展趋势
* 对特殊领域进行深入研究
* 联合发起调研项目
* 设计和实施调研方案
