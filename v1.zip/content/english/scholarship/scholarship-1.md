---
title: "CHEMICAL ENGINEERING"
draft: false
# page title background image
bg_image: "images/backgrounds/page-title.jpg"
# scholarship image
image: "images/scholarship/scholarship-item-1.jpg"
# meta description
description : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. dolore magna aliqua. Ut enim ad minim veniam, quis nostrud."
---

* institutes
* Smart-affiliated research
* Digital Access to Scholarship
* Smart Catalyst
* Smart Library Portal
* Smart research programs